import './App.css'
import Router from './Router'

export default function App() {
  return (
    <div>
      <Router />

    </div>
  )
}


