import React from 'react'

export default function Oversized_tshirts() {
  return (
    <div>Oversized_t-shirts</div>
  )
}
