import React from 'react'

export default function New_arrivals() {
  return (
    <div>New_arrivals</div>
  )
}
