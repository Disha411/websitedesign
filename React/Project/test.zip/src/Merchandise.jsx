import React from 'react'

export default function Merchandise() {
  return (
    <div>Merchandise</div>
  )
}
